/****************************************/
//           NAME: Eric Beckett
// STUDENT NUMBER: 301573524
//         SFU ID: eric_beckett@sfu.ca
/****************************************/

#include <iostream>
#include <stdio.h>
#include <stdlib.h>

#include <string.h>
#include <stdbool.h>

using std::cout;
using std::endl;


int simple_sum(int x, int y)
{
    return x + y;
}


int array_sum(int rand_arr[], int num_elem)
{
    int counting_sum = 0; //a counting variable that holds the continuous sum of the elements in the array

    //looping through the array that was passed in
    for(int i = 0; i < num_elem; i++)
    {
        counting_sum = counting_sum + rand_arr[i]; //adding the respective ith values of the array to counting_sum
    }

    return counting_sum;
}


int find_word(char word_to_search[], char text_to_search[])
{
    int i = 0;
    int j = 0;

    //'\0' is the end of a char, meaning at that point, the char array is empty
    //a while loop terminating when the array hits the ending mark of '\0'
    while((text_to_search[i] != '\0') && (word_to_search[j] != '\0')) 
    {
        //if the first char in the substring doesn't match the first char in the string
        if (word_to_search[j] != text_to_search[i]) 
        {
            i++; //move to the next char in the string
            j = 0; //stay at the same char in the substring
        }
        else
        {
            i++;
            j++;
        }
    }

    if(word_to_search[j] == '\0')
    {
        //subtracting the length of the substring (j) from however far i reached within the string...
        //equates to the position of the first found instance
        return (i - j); 
    }
    else
    {
        return -1;
    }
}

