/****************************************/
//           NAME: Eric Beckett
// STUDENT NUMBER: 301573524
//         SFU ID: eric_beckett@sfu.ca
/****************************************/

#include <iostream>
#include <stdio.h>
#include <stdlib.h>

#include <string.h>
#include <stdbool.h>

using std::cout;
using std::endl;


int simple_sum(int x, int y)
{
    return x + y;
}


int array_sum(int rand_arr[], int num_elem)
{
    int counting_sum = 0;

    for(int i = 0; i < num_elem; i++)
    {
        counting_sum = counting_sum + rand_arr[i]; 
    }

    return counting_sum;
}


int find_word(char word_to_search[], char text_to_search[])
{
    int i = 0;
    int j = 0;
    while((text_to_search[i] != '\0') && (word_to_search[j] != '\0'))
    {
        if (word_to_search[j] != text_to_search[i])
        {
            i++;
            j = 0;
        }
        else
        {
            i++;
            j++;
        }
    }
    if(word_to_search[j] == '\0')
    
    {
        return (i - j);
    }
    else
    {
        return -1;
    }
}

