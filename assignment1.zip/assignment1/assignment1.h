#ifndef ASSIGNMENT1_H
#define ASSIGNMENT1_H

#include <stdbool.h>

/* Question 1 */
int simple_sum(int, int);

/* Question 2 */
int array_sum(int [], int);

/* Question 3 */
int find_word(char [], char []);

#endif