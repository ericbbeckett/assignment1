#include <iostream>
#include <stdio.h>
#include <stdlib.h>

#include <string.h>
#include <stdbool.h>

#include "assignment1.h"




//   SAMPLE TEST CASES FOR QUESTION #1

bool test_q1_1()  {
    if (simple_sum(1, 4) == 5  &&  simple_sum(10, 3) == 13){
        printf("Q1-1 ok\n");
        return true;
    }
    else{
        printf("Q1-1 ERROR\n");
        return false;
    }
}


bool test_q1_2()  {
  if (simple_sum(7, -8)==-1 && simple_sum(-11, -11)==-22)  {
    printf("Q1-2 ok\n");
    return true;
  }
  else  {
    printf("Q1-2 ERROR\n");
    return false;
  }
}



//   SAMPLE TEST CASES FOR QUESTION #2

bool test_q2_1()  {
    int ar[2] = {1,7};
    int total = array_sum(ar, 2);

    if (total==8) {
        printf("Q2-1 ok\n");
        return true;
    }
    else  {
        printf("Q2-1 ERROR\n");
        return false;
    }
}


bool test_q2_2(){
    int ar[6] = {0,-1};
    int total = array_sum(ar, 2);

    if (total==-1) {
        printf("Q2-2 ok\n");
        return true;
    }
    else  {
        printf("Q2-2 ERROR\n");
        return false;
    }
}



//   SAMPLE TEST CASES FOR QUESTION #3

bool test_q3_1(){
    char search_word [] = {"ha"};
    char text_to_search [] = {"that is a cat"};
    char text_to_search2 [] = {"this is a dog"};
    
    // char* search_word = nullptr;
    // char* text_to_search = nullptr;
    // char* text_to_search2 = nullptr;

    // strcpy(search_word, "hat");
    // strcpy(text_to_search, "salad");
    // strcpy(text_to_search2, "cat hat"); 

    if(find_word(search_word, text_to_search)==1 && find_word(search_word, text_to_search2)==-1) {
        printf("Q3-1 ok\n");
        return true;
    }
    else{
        printf("Q3-1 ERROR\n");
        return false;
    }
}


bool test_q3_2(){
    char search_word [] = {"hat"};
    char text_to_search [] = {"salad"};

    if(find_word(search_word, text_to_search) == -1) {
        printf("Q3-2 ok\n");
        return true;
    }
    else{
        printf("Q3-2 ERROR\n");
        return false;
    }
}



// when testing your code comment out
// the test cases you don't need at the moment
int main(){
    test_q1_1();
    test_q1_2();

    test_q2_1();
    test_q2_2();

    test_q3_1();
    test_q3_2();

    return 0;
}