#include <iostream>
#include <stdio.h>
#include <stdlib.h>

#include <string.h>
#include <stdbool.h>

#include <iostream>



int simple_sum(int x, int y)
{
    return x + y;
}

int array_sum(int rand_arr[], int num_elem)
{
    int counting_sum = 0;

    for(int i = 0; i < num_elem; i++)
    {
        counting_sum = counting_sum + rand_arr[i]; 
    }

    return counting_sum;
}

int find_word(char word_to_search[], char text_to_search[])
{
    int i = 0;
    int j = 0;
    while((text_to_search[i] != '\0') && (word_to_search[j] != '\0'))
    {
        if (word_to_search[j] != text_to_search[i])
        {
            i++;
            j = 0;
        }
        else
        {
            i++;
            j++;
        }
    }
    if(word_to_search[j] == '\0')
    
    {
        return (i - j);
    }
    else
    {
        return -1;
    }
}

int main() {

    int a = 5, b = 3;

    // Test case 1
    int result = simple_sum(a, b);
    if (result == 8) {
        std::cout << "Test case 1 passed" << std::endl;
    } else {
        std::cout << "Test case 1 failed" << std::endl;
    }

    // Test case 2
    a = 0;
    b = 0;
    result = simple_sum(a, b);
    if (result == 0) {
        std::cout << "Test case 2 passed" << std::endl;
    } else {
        std::cout << "Test case 2 failed" << std::endl;
    }

    // Test case 3
    a = -5;
    b = 10;
    result = simple_sum(a, b);
    if (result == 5) {
        std::cout << "Test case 3 passed" << std::endl;
    } else {
        std::cout << "Test case 3 failed" << std::endl;
    }

    // Test case 4
    a = -3;
    b = -4;
    result = simple_sum(a, b);
    if (result == -7) {
        std::cout << "Test case 4 passed" << std::endl;
    } else {
        std::cout << "Test case 4 failed" << std::endl;
    }


    int arr1[] = {1, 2, 3, 4, 5};
    int n1 = 5;
    // Test case 1
    result = array_sum(arr1, n1);
    if (result == 15) {
        std::cout << "Test case 1 (array) passed" << std::endl;
    } else {
        std::cout << "Test case 1 (array) failed" << std::endl;
    }

    int arr2[] = {0, 0, 0, 0, 0};
    int n2 = 5;
    // Test case 2
    result = array_sum(arr2, n2);
    if (result == 0) {
        std::cout << "Test case 2 (array) passed" << std::endl;
    } else {
        std::cout << "Test case 2 (array) failed" << std::endl;
    }


    int arr3[] = {-1, -2, -3, -4, -5};
    int n3 = 5;
    // Test case 3
    result = array_sum(arr3, n3);
    if (result == -15) {
        std::cout << "Test case 3 (array) passed" << std::endl;
    } else {
        std::cout << "Test case 3 (array) failed" << std::endl;
    }


    char word1[] = "hello";
    char text1[] = "hello world";
    // Test case 1
    result = find_word(word1, text1);
    if (result == 0) {
        std::cout << "Test case 1 passed" << std::endl;
    } else {
        std::cout << "Test case 1 failed" << std::endl;
    }

    char word2[] = "world";
    char text2[] = "hello world";
    // Test case 2
    result = find_word(word2, text2);
    if (result == 6) {
        std::cout << "Test case 2 passed" << std::endl;
    } else {
        std::cout << "Test case 2 failed" << std::endl;
    }

    char word3[] = "worlds";
    char text3[] = "hello world";
    // Test case 3
    result = find_word(word3, text3);
    if (result == -1) {
        std::cout << "Test case 3 passed" << std::endl;
    } else {
        std::cout << "Test case 3 failed" << std::endl;
    }

    return 0;
}



